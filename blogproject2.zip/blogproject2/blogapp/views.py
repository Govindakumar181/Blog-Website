from django.shortcuts import render

# Create your views here.
def index(request):
    return render(request,'blogapp/index.html')

def postdesc(request):
    return render(request,'blogapp/postdesc.html')

def contact(request):
    return render(request,'blogapp/contact.html')