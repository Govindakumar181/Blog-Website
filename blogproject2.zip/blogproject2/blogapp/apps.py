from django.apps import AppConfig


class BlogappConfig(AppConfig):
    name = 'blogapp'
